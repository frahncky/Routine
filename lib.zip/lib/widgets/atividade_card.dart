import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:routine_planner/data/models/atividade.dart';
import 'package:routine_planner/data/services/firestore_service.dart';
import 'package:routine_planner/features/home/cadastro_atividade_screen.dart';

class AtividadeCard extends StatelessWidget {
  final Atividade atividade;
  final Future<void> Function(Atividade) aoAtualizar;
  final FirestoreService firestoreService;

  const AtividadeCard({
    super.key,
    required this.atividade,
    required this.aoAtualizar,
    required this.firestoreService,
  });

  bool get estaConcluida => atividade.statusManual == 'concluida';

  bool get estaAtrasada {
    final agora = DateTime.now();
    return !estaConcluida && atividade.horaTermino.isBefore(agora);
  }

  bool get estaEmAndamento {
    final agora = DateTime.now();
    return atividade.horaInicio.isBefore(agora) && atividade.horaTermino.isAfter(agora);
  }

  Color get corStatus {
    if (estaConcluida) return Colors.green.withOpacity(0.2);
    if (estaAtrasada) return Colors.red.withOpacity(0.15);
    if (estaEmAndamento) return Colors.blue.withOpacity(0.15);
    return Colors.grey.withOpacity(0.08);
  }

  IconData get iconeStatus {
    if (estaConcluida) return Icons.check_circle;
    if (estaAtrasada) return Icons.warning_amber;
    if (estaEmAndamento) return Icons.play_arrow;
    return Icons.schedule;
  }

  String get textoStatus {
    if (estaConcluida) return "Concluída";
    if (estaAtrasada) return "Atrasada";
    if (estaEmAndamento) return "Em andamento";
    return "Pendente";
  }

  @override
  Widget build(BuildContext context) {
    final formatter = DateFormat('HH:mm');
    final hora = "${formatter.format(atividade.horaInicio)} - ${formatter.format(atividade.horaTermino)}";
    final usuario = firestoreService.usuarioAtualEmail;

    return GestureDetector(
      onTap: () async {
        final editada = await Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => CadastroAtividadeScreen(atividade: atividade),
        ));
        if (editada != null && editada is Atividade) {
          await aoAtualizar(editada);
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: corStatus,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.grey.shade200),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(2, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(iconeStatus, color: Colors.black54, size: 20),
                const SizedBox(width: 8),
                Text(
                  textoStatus,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                const Spacer(),
                Checkbox(
                  value: estaConcluida,
                  onChanged: (checked) async {
                    final nova = atividade.copyWith(statusManual: checked! ? 'concluida' : 'pendente');
                    await aoAtualizar(nova);
                  },
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              atividade.titulo,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            if (atividade.descricao.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  atividade.descricao,
                  style: TextStyle(color: Colors.grey.shade800),
                ),
              ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.access_time, size: 16),
                const SizedBox(width: 4),
                Text(hora),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: atividade.convidados.map((convidado) {
                IconData icone;
                Color cor;
                switch (convidado.status) {
                  case 'aceito':
                    icone = Icons.check;
                    cor = Colors.green;
                    break;
                  case 'recusado':
                    icone = Icons.close;
                    cor = Colors.red;
                    break;
                  default:
                    icone = Icons.hourglass_empty;
                    cor = Colors.grey;
                }

                final souEu = convidado.email == usuario;
                return Tooltip(
                  message: "${souEu ? 'Você' : convidado.nome} (${convidado.status})",
                  child: CircleAvatar(
                    radius: 20,
                    backgroundColor: Colors.grey.shade100,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Text(
                          convidado.nome.substring(0, 1).toUpperCase(),
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Icon(icone, size: 14, color: cor),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
