
import 'package:flutter/material.dart';

class ConfiguracoesScreen extends StatelessWidget {
  const ConfiguracoesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Configurações")),
      body: ListView(
        children: [
          const ListTile(
            leading: Icon(Icons.person),
            title: Text("Usuário: usuario@exemplo.com"),
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.star),
            title: Text("Plano: Família"),
            subtitle: Text("Repetição e atividades compartilhadas liberadas."),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.brightness_6),
            title: const Text("Alternar Tema (Simulado)"),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Tema alternado (simulado).")),
             //   setState(() {
                 // mudar_thema  = !mudar_thema;

             //   });
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.info),
            title: const Text("Sobre o aplicativo"),
            subtitle: const Text("Routine Planner v1.0"),
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text("Sair (Simulado)"),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Logout realizado (simulado).")),
              );
            },
          ),
        ],
      ),
    );
  }
}
