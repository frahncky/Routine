import 'package:flutter/material.dart';
import '../../data/models/atividade.dart';
import '../../data/services/firestore_service.dart';

class HistoricoScreen extends StatefulWidget {
  const HistoricoScreen({super.key});

  @override
  State<HistoricoScreen> createState() => _HistoricoScreenState();
}

class _HistoricoScreenState extends State<HistoricoScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  List<Atividade> _historico = [];

  @override
  void initState() {
    super.initState();
    _carregarHistorico();
  }

  Future<void> _carregarHistorico() async {
    final todas = await _firestoreService.getAtividades();
    setState(() {
      _historico = todas
          .where((a) => a.status == StatusAtividade.executada)
          .toList();
    });
  }

  Future<void> _reutilizarAtividade(Atividade original) async {
    final nova = Atividade(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      titulo: original.titulo,
      descricao: original.descricao,
      data: DateTime.now(),
      horaInicio: original.horaInicio,
      horaFim: original.horaFim,
      diasRepeticao: original.diasRepeticao,
      convidados: original.convidados,
      criadorEmail: original.criadorEmail,
      status: StatusAtividade.emExecucao,
    );
    await _firestoreService.salvarAtividade(nova);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Atividade reutilizada.")),
    );
    _carregarHistorico(); // opcional para atualizar
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Histórico")),
      body: _historico.isEmpty
          ? const Center(child: Text("Nenhuma atividade concluída."))
          : ListView.builder(
              itemCount: _historico.length,
              itemBuilder: (_, i) {
                final atividade = _historico[i];
                return ListTile(
                  leading: const Icon(Icons.check_circle_outline),
                  title: Text(atividade.titulo),
                  subtitle: Text(
                      "Finalizada em ${atividade.data.day}/${atividade.data.month}/${atividade.data.year}"),
                  trailing: IconButton(
                    icon: const Icon(Icons.repeat),
                    tooltip: 'Reutilizar',
                    onPressed: () => _reutilizarAtividade(atividade),
                  ),
                );
              },
            ),
    );
  }
}
