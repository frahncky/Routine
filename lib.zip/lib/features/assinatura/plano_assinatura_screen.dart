
import 'package:flutter/material.dart';

class PlanoAssinaturaScreen extends StatelessWidget {
  const PlanoAssinaturaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Planos de Assinatura")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          PlanoCard(
            titulo: "Gratuito",
            descricao: "Até 5 atividades por dia.",
          ),
          PlanoCard(
            titulo: "Individual",
            descricao: "Atividades ilimitadas.",
          ),
          PlanoCard(
            titulo: "Família",
            descricao: "Compartilhamento + repetição semanal.",
          ),
        ],
      ),
    );
  }
}

class PlanoCard extends StatelessWidget {
  final String titulo;
  final String descricao;

  const PlanoCard({super.key, required this.titulo, required this.descricao});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(titulo, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(descricao),
        trailing: ElevatedButton(onPressed: () {}, child: const Text("Selecionar")),
      ),
    );
  }
}
