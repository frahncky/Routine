import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:routine_planner/data/models/atividade.dart';

class CadastroAtividadeScreen extends StatefulWidget {
  final Atividade? atividadeExistente;

  const CadastroAtividadeScreen({super.key, this.atividadeExistente});

  @override
  State<CadastroAtividadeScreen> createState() => _CadastroAtividadeScreenState();
}

class _CadastroAtividadeScreenState extends State<CadastroAtividadeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _tituloController = TextEditingController();
  final _descricaoController = TextEditingController();
  final _emailController = TextEditingController();

  DateTime _dataSelecionada = DateTime.now();
  TimeOfDay _horaInicio = const TimeOfDay(hour: 8, minute: 0);
  TimeOfDay _horaFim = const TimeOfDay(hour: 9, minute: 0);
  List<String> _diasRepeticao = [];
  List<Convidado> _convidados = [];

  final diasSemana = [
    'Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb',
  ];

  @override
  void initState() {
    super.initState();
    if (widget.atividadeExistente != null) {
      final a = widget.atividadeExistente!;
      _tituloController.text = a.titulo;
      _descricaoController.text = a.descricao;
      _dataSelecionada = a.data;
      _horaInicio = a.horaInicio;
      _horaFim = a.horaFim;
      _diasRepeticao = List.from(a.diasRepeticao);
      _convidados = List.from(a.convidados);
    }
  }

  Future<void> _selecionarData() async {
    final selecionada = await showDatePicker(
      context: context,
      initialDate: _dataSelecionada,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (selecionada != null) {
      setState(() => _dataSelecionada = selecionada);
    }
  }

  Future<void> _selecionarHoraInicio() async {
    final selecionada = await showTimePicker(
      context: context,
      initialTime: _horaInicio,
    );
    if (selecionada != null) {
      setState(() => _horaInicio = selecionada);
    }
  }

  Future<void> _selecionarHoraFim() async {
    final selecionada = await showTimePicker(
      context: context,
      initialTime: _horaFim,
    );
    if (selecionada != null) {
      setState(() => _horaFim = selecionada);
    }
  }

  void _adicionarConvidado() {
    final email = _emailController.text.trim();
    if (email.isNotEmpty && !_convidados.any((c) => c.email == email)) {
      setState(() {
        _convidados.add(Convidado(email: email, status: ''));
        _emailController.clear();
      });
    }
  }

  void _removerConvidado(String email) {
    setState(() {
      _convidados.removeWhere((c) => c.email == email);
    });
  }

  void _salvar() {
    if (_formKey.currentState!.validate()) {
      final novaAtividade = Atividade(
        id: widget.atividadeExistente?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
        titulo: _tituloController.text,
        descricao: _descricaoController.text,
        data: _dataSelecionada,
        horaInicio: _horaInicio,
        horaFim: _horaFim,
        diasRepeticao: _diasRepeticao,
        convidados: _convidados,
        criadorEmail: widget.atividadeExistente?.criadorEmail ?? 'usuario@teste.com',
        status: widget.atividadeExistente?.status ?? StatusAtividade.emExecucao,
      );

      Navigator.of(context).pop(novaAtividade);
    }
  }

  @override
  Widget build(BuildContext context) {
    final formatadorData = DateFormat('dd/MM/yyyy');
    final formatadorHora = (TimeOfDay t) =>
        t.hour.toString().padLeft(2, '0') + ':' + t.minute.toString().padLeft(2, '0');

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.atividadeExistente != null ? 'Editar Atividade' : 'Nova Atividade'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _tituloController,
                decoration: const InputDecoration(labelText: 'Título'),
                validator: (v) => v == null || v.isEmpty ? 'Informe o título' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _descricaoController,
                decoration: const InputDecoration(labelText: 'Descrição'),
              ),
              const SizedBox(height: 12),
              ListTile(
                title: Text('Data: ${formatadorData.format(_dataSelecionada)}'),
                trailing: const Icon(Icons.calendar_today),
                onTap: _selecionarData,
              ),
              ListTile(
                title: Text('Início: ${formatadorHora(_horaInicio)}'),
                trailing: const Icon(Icons.access_time),
                onTap: _selecionarHoraInicio,
              ),
              ListTile(
                title: Text('Fim: ${formatadorHora(_horaFim)}'),
                trailing: const Icon(Icons.access_time_filled),
                onTap: _selecionarHoraFim,
              ),
              const SizedBox(height: 12),
              const Text('Repetir nos dias:'),
              Wrap(
                spacing: 6,
                children: diasSemana.map((dia) {
                  final selecionado = _diasRepeticao.contains(dia);
                  return FilterChip(
                    label: Text(dia),
                    selected: selecionado,
                    onSelected: (seleciona) {
                      setState(() {
                        if (seleciona) {
                          _diasRepeticao.add(dia);
                        } else {
                          _diasRepeticao.remove(dia);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              const Divider(height: 32),
              const Text('Convidados'),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _emailController,
                      decoration: const InputDecoration(labelText: 'E-mail'),
                    ),
                  ),
                  IconButton(
                    onPressed: _adicionarConvidado,
                    icon: const Icon(Icons.person_add),
                  ),
                ],
              ),
              ..._convidados.map((c) => ListTile(
                    title: Text(c.email),
                    trailing: IconButton(
                      icon: const Icon(Icons.remove_circle, color: Colors.red),
                      onPressed: () => _removerConvidado(c.email),
                    ),
                  )),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _salvar,
                icon: const Icon(Icons.check),
                label: const Text('Salvar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
