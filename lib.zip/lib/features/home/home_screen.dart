import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:routine_planner/data/models/atividade.dart';
import 'package:routine_planner/data/models/convidado.dart';
import 'package:routine_planner/data/services/firestore_service.dart';

class CadastroAtividadeScreen extends StatefulWidget {
  final Atividade? atividade;

  const CadastroAtividadeScreen({super.key, this.atividade});

  @override
  State<CadastroAtividadeScreen> createState() => _CadastroAtividadeScreenState();
}

class _CadastroAtividadeScreenState extends State<CadastroAtividadeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _tituloController = TextEditingController();
  final _descricaoController = TextEditingController();
  DateTime _data = DateTime.now();
  TimeOfDay _horaInicio = const TimeOfDay(hour: 8, minute: 0);
  TimeOfDay _horaTermino = const TimeOfDay(hour: 9, minute: 0);
  List<Convidado> _convidados = [];
  bool _concluida = false;

  @override
  void initState() {
    super.initState();
    final atividade = widget.atividade;
    if (atividade != null) {
      _tituloController.text = atividade.titulo;
      _descricaoController.text = atividade.descricao;
      _data = atividade.data;
      _horaInicio = TimeOfDay.fromDateTime(atividade.horaInicio);
      _horaTermino = TimeOfDay.fromDateTime(atividade.horaTermino);
      _convidados = List.from(atividade.convidados);
      _concluida = atividade.concluida;
    }
  }

  Future<void> _selecionarHora(BuildContext context, bool inicio) async {
    final selecionada = await showTimePicker(
      context: context,
      initialTime: inicio ? _horaInicio : _horaTermino,
    );
    if (selecionada != null) {
      setState(() {
        if (inicio) {
          _horaInicio = selecionada;
        } else {
          _horaTermino = selecionada;
        }
      });
    }
  }

  void _adicionarConvidado() {
    showDialog(
      context: context,
      builder: (context) {
        final nomeController = TextEditingController();
        final emailController = TextEditingController();
        return AlertDialog(
          title: const Text('Adicionar Convidado'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nomeController,
                decoration: const InputDecoration(labelText: 'Nome'),
              ),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'E-mail'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                final nome = nomeController.text.trim();
                final email = emailController.text.trim();
                if (nome.isNotEmpty && email.isNotEmpty) {
                  setState(() {
                    _convidados.add(Convidado(nome: nome, email: email));
                  });
                  Navigator.pop(context);
                }
              },
              child: const Text('Adicionar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final formatter = DateFormat('dd/MM/yyyy');
    return Scaffold(
      appBar: AppBar(title: Text(widget.atividade == null ? 'Nova Atividade' : 'Editar Atividade')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _tituloController,
                decoration: const InputDecoration(labelText: 'Título'),
                validator: (value) => value == null || value.isEmpty ? 'Informe um título' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _descricaoController,
                decoration: const InputDecoration(labelText: 'Descrição'),
                maxLines: 2,
              ),
              const SizedBox(height: 10),
              ListTile(
                title: const Text('Data'),
                subtitle: Text(formatter.format(_data)),
                trailing: const Icon(Icons.calendar_today),
                onTap: () async {
                  final selecionada = await showDatePicker(
                    context: context,
                    initialDate: _data,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                  if (selecionada != null) {
                    setState(() => _data = selecionada);
                  }
                },
              ),
              ListTile(
                title: const Text('Hora de Início'),
                subtitle: Text(_horaInicio.format(context)),
                trailing: const Icon(Icons.access_time),
                onTap: () => _selecionarHora(context, true),
              ),
              ListTile(
                title: const Text('Hora de Término'),
                subtitle: Text(_horaTermino.format(context)),
                trailing: const Icon(Icons.access_time),
                onTap: () => _selecionarHora(context, false),
              ),
              SwitchListTile(
                title: const Text('Marcar como concluída'),
                value: _concluida,
                onChanged: (value) => setState(() => _concluida = value),
              ),
              const Divider(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Convidados', style: TextStyle(fontWeight: FontWeight.bold)),
                  IconButton(
                    onPressed: _adicionarConvidado,
                    icon: const Icon(Icons.person_add),
                  ),
                ],
              ),
              ..._convidados.map((c) => ListTile(
                    leading: const Icon(Icons.person),
                    title: Text(c.nome),
                    subtitle: Text(c.email),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        setState(() => _convidados.remove(c));
                      },
                    ),
                  )),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final now = DateTime.now();
                    final dataInicio = DateTime(_data.year, _data.month, _data.day, _horaInicio.hour, _horaInicio.minute);
                    final dataFim = DateTime(_data.year, _data.month, _data.day, _horaTermino.hour, _horaTermino.minute);
                    final nova = Atividade(
                      id: widget.atividade?.id ?? '',
                      titulo: _tituloController.text.trim(),
                      descricao: _descricaoController.text.trim(),
                      data: _data,
                      horaInicio: dataInicio,
                      horaTermino: dataFim,
                      convidados: _convidados,
                      concluida: _concluida,
                    );
                    Navigator.pop(context, nova);
                  }
                },
                child: const Text('Salvar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
