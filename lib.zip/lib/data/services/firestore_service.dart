import 'dart:async';
import 'package:uuid/uuid.dart';
import '../models/atividade.dart';

class FirestoreService {
  final Map<String, Map<String, dynamic>> _atividades = {};
  final _uuid = const Uuid();

  String get usuarioAtualEmail => 'usuario@exemplo.com';

  Future<void> salvarAtividade(Atividade atividade) async {
    final id = atividade.id.isEmpty ? _uuid.v4() : atividade.id;
    final novaAtividade = atividade.copyWith(id: id);
    _atividades[id] = novaAtividade.toMap();
    await Future.delayed(const Duration(milliseconds: 300)); // Simula delay
  }

  Future<void> excluirAtividade(String id) async {
    _atividades.remove(id);
    await Future.delayed(const Duration(milliseconds: 300)); // Simula delay
  }

  Future<List<Atividade>> getAtividades() async {
    await Future.delayed(const Duration(milliseconds: 300)); // Simula delay
    return _atividades.values
        .map((map) => Atividade.fromMap(map))
        .toList();
  }

  Future<Atividade?> buscarPorId(String id) async {
    final data = _atividades[id];
    if (data == null) return null;
    return Atividade.fromMap(data);
  }
}
