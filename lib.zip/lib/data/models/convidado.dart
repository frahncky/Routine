class Convidado {
  final String nome;
  final String email;
  final String status; // 'aceito', 'recusado', 'pendente'

  Convidado({
    required this.nome,
    required this.email,
    this.status = 'pendente',
  });

  Convidado copyWith({
    String? nome,
    String? email,
    String? status,
  }) {
    return Convidado(
      nome: nome ?? this.nome,
      email: email ?? this.email,
      status: status ?? this.status,
    );
  }

  factory Convidado.fromMap(Map<String, dynamic> map) {
    return Convidado(
      nome: map['nome'] ?? '',
      email: map['email'] ?? '',
      status: map['status'] ?? 'pendente',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'nome': nome,
      'email': email,
      'status': status,
    };
  }
}
