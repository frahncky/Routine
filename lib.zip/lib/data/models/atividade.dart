import 'package:flutter/material.dart';

enum StatusAtividade { emExecucao, executada, atrasada }

class Convidado {
  final String email;
  final String status;

  Convidado({required this.email, required this.status});

  factory Convidado.fromMap(Map<String, dynamic> map) {
    return Convidado(
      email: map['email'],
      status: map['status'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'status': status,
    };
  }
}

class Atividade {
  final String id;
  final String titulo;
  final String descricao;
  final DateTime data;
  final TimeOfDay horaInicio;
  final TimeOfDay horaFim;
  final List<String> diasRepeticao;
  final List<Convidado> convidados;
  final String criadorEmail;
  final StatusAtividade status;
  final bool deletar;

  Atividade({
    required this.id,
    required this.titulo,
    required this.descricao,
    required this.data,
    required this.horaInicio,
    required this.horaFim,
    required this.diasRepeticao,
    required this.convidados,
    required this.criadorEmail,
    required this.status,
    this.deletar = false,
  });

  Atividade copyWith({
    String? id,
    String? titulo,
    String? descricao,
    DateTime? data,
    TimeOfDay? horaInicio,
    TimeOfDay? horaFim,
    List<String>? diasRepeticao,
    List<Convidado>? convidados,
    String? criadorEmail,
    StatusAtividade? status,
    bool? deletar,
  }) {
    return Atividade(
      id: id ?? this.id,
      titulo: titulo ?? this.titulo,
      descricao: descricao ?? this.descricao,
      data: data ?? this.data,
      horaInicio: horaInicio ?? this.horaInicio,
      horaFim: horaFim ?? this.horaFim,
      diasRepeticao: diasRepeticao ?? this.diasRepeticao,
      convidados: convidados ?? this.convidados,
      criadorEmail: criadorEmail ?? this.criadorEmail,
      status: status ?? this.status,
      deletar: deletar ?? this.deletar,
    );
  }

  factory Atividade.fromMap(Map<String, dynamic> map) {
    return Atividade(
      id: map['id'],
      titulo: map['titulo'],
      descricao: map['descricao'],
      data: DateTime.parse(map['data']),
      horaInicio: _fromStringToTimeOfDay(map['horaInicio']),
      horaFim: _fromStringToTimeOfDay(map['horaFim']),
      diasRepeticao: List<String>.from(map['diasRepeticao'] ?? []),
      convidados: (map['convidados'] as List<dynamic>)
          .map((e) => Convidado.fromMap(e))
          .toList(),
      criadorEmail: map['criadorEmail'],
      status: StatusAtividade.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => StatusAtividade.emExecucao,
      ),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'titulo': titulo,
      'descricao': descricao,
      'data': data.toIso8601String(),
      'horaInicio': _fromTimeOfDayToString(horaInicio),
      'horaFim': _fromTimeOfDayToString(horaFim),
      'diasRepeticao': diasRepeticao,
      'convidados': convidados.map((e) => e.toMap()).toList(),
      'criadorEmail': criadorEmail,
      'status': status.name,
    };
  }

  static TimeOfDay _fromStringToTimeOfDay(String str) {
    final parts = str.split(':');
    return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
  }

  static String _fromTimeOfDayToString(TimeOfDay t) {
    return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }
}
